#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)

int main() {
	long long int n = 0;
	while (1) {
		scanf("%lld", &n);
		if (n == 0) {
			break;
		}

		while (1) {
			long long int sum = 0;
			sum = sum + n % 10;
			while (1) {
				n = n / 10;
				sum = sum + n % 10;
				if (n < 10) {
					break;
				}
			}
			if (sum >= 10) {
				n = sum;
			}
			if (sum < 10) {
				printf("%lld\n", sum);
				break;
			}
		}
	}
	system("pause");
	return 0;
}