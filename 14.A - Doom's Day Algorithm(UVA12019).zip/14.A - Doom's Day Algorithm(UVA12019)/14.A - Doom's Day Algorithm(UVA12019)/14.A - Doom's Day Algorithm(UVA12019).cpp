#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
/*
1 3 5 7 8 10 12-> 31
4 6 9 11-> 30
2 -> 28

*/
int main() {
	int test = 0;
	int m = 0, d = 0;
	int days = 0;
	scanf("%d", &test);
	for (int i = 0; i < test; i++) {
		scanf("%d %d", &m, &d);
		if (m == 1) {
			days = d;
		}
		else if (m == 2) {
			days = 31 + d;
		}
		else if (m == 3) {
			days = 59 + d;
		}
		else if (m == 4) {
			days = 90 + d;
		}
		else if (m == 5) {
			days = 120 + d;
		}
		else if (m == 6) {
			days = 151 + d;
		}
		else if (m == 7) {
			days = 181 + d;
		}
		else if (m == 8) {
			days = 212 + d;
		}
		else if (m == 9) {
			days = 243 + d;
		}
		else if (m == 10) {
			days = 273 + d;
		}
		else if (m == 11) {
			days = 304 + d;
		}
		else {
			days = 334 + d;
		}

		if (days % 7 == 1) {
			printf("Saturday\n");
		}
		else if (days % 7 == 2) {
			printf("Sunday\n");
		}
		else if (days % 7 == 3) {
			printf("Monday\n");
		}
		else if (days % 7 == 4) {
			printf("Tuesday\n");
		}
		else if (days % 7 == 5) {
			printf("Wednesday\n");
		}
		else if (days % 7 == 6) {
			printf("Thursday\n");
		}
		else {
			printf("Friday\n");
		}
	}
	system("psuse");
	return 0;
}