#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int n = 0;
	while (scanf("%d", &n) != EOF) {
		int flag = 0;
		int arr[3005] = { 0 };
		int brr[3005] = { 0 };
		for (int i = 0; i < n; i++) {
			scanf("%d", &arr[i]);
		}
		for (int i = 0; i < n - 1; i++) {
			 brr[i] = abs(arr[i] - arr[i + 1]);
		}
		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j < n - i - 2; j++) {
				if (brr[j] > brr[j + 1]) {
					int temp = brr[j];
					brr[j] = brr[j + 1];
					brr[j + 1] = temp;
				}
			}
		}
		for (int i = 0; i < n - 1; i++) {
			if (brr[i] != i + 1) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			printf("Jolly\n");
		}
		else if (flag == 1) {
			printf("Not jolly\n");
		}
	}
	system("pause");
	return 0;
}