#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
#define lld long long int

int main() {
	lld S, D = 0;
	while (scanf("%lld %lld", &S, &D) != EOF) {
		lld sum = 0;
		while (1) {
			sum = sum + S;
			if (sum >= D) {
				printf("%lld\n", S);
				break;
			}
			S++;
		}
	}
	system("pause");
	return 0;
}