#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)

int main() {
	int x = 0;
	while (scanf("%d", &x) != EOF) {
	
	}
	system("pause");
	return 0;
}