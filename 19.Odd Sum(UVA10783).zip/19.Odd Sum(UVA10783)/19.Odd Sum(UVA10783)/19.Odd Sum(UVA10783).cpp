#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int T = 0;
	scanf("%d", &T);
	int arr[2] = { 0 };
	for (int j = 0; j < T; j++) {
		for (int i = 0; i < 2; i++) {
			scanf("%d", &arr[i]);
		}
		int sum = 0;
			if (arr[0] % 2 == 0) {
				arr[0] = arr[0] + 1;
			}
			if (arr[1] % 2 == 0) {
				arr[1] = arr[1] - 1;
			}
			sum = (arr[0] + arr[1])*((arr[1] - arr[0]) / 2 + 1) / 2;
		printf("Case %d: %d\n", j + 1, sum);
	}
	system("pause");
	return 0;
}