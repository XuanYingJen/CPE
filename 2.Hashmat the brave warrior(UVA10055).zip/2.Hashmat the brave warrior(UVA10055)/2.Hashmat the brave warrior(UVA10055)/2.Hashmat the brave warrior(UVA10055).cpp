#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)

int main() {
	long long int a, b = 0;
	while (scanf("%lld %lld", &a, &b) != EOF) {
		printf("%lld\n", abs(a - b));
	}
	system("pause");
	return 0;
}