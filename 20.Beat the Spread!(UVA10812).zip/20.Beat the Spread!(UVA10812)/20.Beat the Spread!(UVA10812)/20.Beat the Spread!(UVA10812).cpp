#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int n = 0;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int s = 0, d = 0;
		scanf("%d %d", &s, &d);
		int flag = 0;
		if ((s + d) % 2 == 1) {
			flag = 1;
		}
		int teamB = (s - d) / 2;
		int teamA = s - teamB;
		int flag1 = 0, flag2 = 0;
		if (flag == 0) {
			if (teamA < 0 || teamB < 0) {
				printf("impossible\n");
			}
			else {
				if (teamA >= teamB) {
					printf("%d %d\n", teamA, teamB);
				}
				else if (teamB > teamA) {
					printf("%d %d\n", teamB, teamA);
				}
			}
		}
		else
			printf("impossible\n");
	}
	system("pause");
	return 0;
}