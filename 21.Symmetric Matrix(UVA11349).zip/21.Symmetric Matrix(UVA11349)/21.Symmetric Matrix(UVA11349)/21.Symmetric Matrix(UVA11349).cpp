#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int test = 0;
	scanf("%d", &test);
	getchar();
	int count = 0;
	for (int i = 0; i < test; i++) {
		int flag = 1;
		int N = 0;
		char str[10] = { 0 };
		long long int arr[105][105];
		scanf("%s%s%d", str, str, &N);
		count++;
		for (int m = 0; m < N; m++) {
			for (int n = 0; n < N; n++) {
				scanf("%lld", &arr[m][n]);
			}
		}
		getchar();
		for (int m = 0; m < N; m++) {
			for (int n = 0; n < N; n++) {
				if (arr[m][n] != arr[N-1-m][N-1-n] || arr[m][n] < 0) {
					flag = 0;
					break;
				}
			}
			if (flag == 0) break;
		}
		printf("Test #%d: ", count);
		if (flag == 1) {
			printf("Symmetric.\n");
		}
		else if(flag == 0){
			printf("Non-symmetric.\n");
		}

	}
	system("pause");
	return 0;
}