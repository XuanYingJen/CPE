#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#pragma warning(disable:4996)

int main() {
	while (1) {
		int a = 0, b = 0;
		scanf("%d %d", &a, &b);
		if (a == 0 && b == 0) {
			break;
		}
		int count = 0;
		for (int i = (int)sqrt(a); (int)pow(i, 2) <= b; i++) {
			if ((int)pow(i, 2) >= a && (int)pow(i, 2) <= b) {
				count++;
			}
		}
		printf("%d\n", count);
	}
	system("pause");
	return 0;
}