#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	
	int N = 0;
	int Case = 0;
	while (scanf("%d", &N) != EOF) {
		int arr[105] = { 0 };
		int brr[5055] = { 0 };
		int flag = 0;
		Case++;
		for (int i = 0; i < N; i++) {
			scanf("%d", &arr[i]);
		}
		int k = 0;
		for (int i = 0; i < N - 1; i++) {
			if (arr[i] >= arr[i + 1] || arr[0] < 1) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			for (int i = 0; i < N - 1; i++) {
				for (int j = i; j < N; j++) {
					brr[k] = arr[i] + arr[j];
					k++;
				}
			}
			for (int i = 0; i < k; i++) {
				for (int j = i+1; j < k; j++) {
					if (brr[i] == brr[j]) {
						flag = 1;
						break;
					}
				}
				if (flag == 1) {
					break;
				}
			}
		}
		if (flag == 1) {
			printf("Case #%d: It is not a B2-Sequence.\n\n", Case);
		}
		else {
			printf("Case #%d: It is a B2-Sequence.\n\n", Case);
		}
	}
	system("pause");
	return 0;
}