#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)

int main() {
	int v = 0, t = 0;
	while (scanf("%d %d", &v, &t) != EOF) {
		printf("%d\n", 2 * v*t);
	}
	system("pause");
	return 0;
 }
/*
��t�׬�0!!!
S = Vot + 1/2 at * t
  = 0 + 1/2 V/t * t * t
  =2Vt
*/