#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int N = 0;
	scanf("%d", &N);
	for (int i = 0; i < N; i++) {
		int M = 0, N = 0;
		int b1 = 0, b2 = 0;
		int A = 0, B = 0, C = 0, D = 0;
		scanf("%d", &M);
		N = M;
		while (1) {
			if (M == 1) {
				b1++;
				break;
			}
			else if (M % 2 == 1) {
				M = M / 2;
				b1++;
			}
			else M = M / 2;
		}
		if (N == 1) {
			b2 = 1;
		}
		else {
			while (1) {
				if (N == 1) {
					b2++;
					break;
				}
				if (N >= 1000) {
					A = (N - N % 1000) / 1000;
					N = N - 1000 * A;
					while (1) {
						if (A == 1) {
							b2++;
							break;
						}
						else if (A % 2 == 1) {
							A = A / 2;
							b2++;
						}
						else A = A / 2;
					}
				}
				else if (N >= 100 && N < 1000) {
					B = (N - N % 100) / 100;
					N = N - 100 * B;
					while (1) {
						if (B == 1) {
							b2++;
							break;
						}
						else if (B % 2 == 1) {
							B = B / 2;
							b2++;
						}
						else B = B / 2;
					}
				}
				else if (N < 100 && N >= 10) {
					C = (N - N % 10) / 10;
					N = N - 10 * C;
					while (1) {
						if (C == 1) {
							b2++;
							break;
						}
						else if (C % 2 == 1) {
							C = C / 2;
							b2++;
						}
						else C = C / 2;
					}
				}
				else {
					while (1) {
						if (N == 1) {
							break;
						}
						else if (N % 2 == 1) {
							N = N / 2;
							b2++;
						}
						else N = N / 2;
					}
				}
			}
		}
		printf("%d %d\n", b1, b2);
	}
	system("pause");
	return 0;
}