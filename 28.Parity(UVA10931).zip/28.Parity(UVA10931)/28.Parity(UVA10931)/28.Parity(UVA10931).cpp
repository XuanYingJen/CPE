#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)

int main() {
	int I = 0;
	while (1) {
		int n = 0;
		int count = 0;
		int arr[100000] = { 0 };
		scanf("%d", &I);
		if (I == 0) {
			break;
		}
		for (int i = 0; i >= 0; i++) {
			if (I == 0) {
					break;
			}
			else if (I % 2 == 1) {
				I = I / 2;
				arr[i] = 1;
				count++;
				n++;
			}
			else if (I % 2 != 1) {
				I = I / 2;
				arr[i] = 0;
				count++;
			}
		}
		printf("The parity of ");
		for (int i = count - 1; i >= 0; i--) {
			printf("%d", arr[i]);
		}
		printf(" is %d (mod 2).\n", n);
	}
	system("pause");
	return 0;
}