#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)

int main() {
	long long int a, b = 0;
	int sum = 0;
	bool plus = false;
	while (true) {
		scanf("%lld %lld", &a, &b);
		sum = 0;
		plus = false;
		if (a == 0 && b == 0) {
			break;
		}
		while (true) {
			if ((a % 10) + (b % 10) + (plus ? 1 : 0) >= 10) {
				sum++;
				plus = true;
			}
			else
			{
				plus = false;
			}
			a = a / 10;
			b = b / 10;
			if ((a == 0 || b == 0) && (a % 10) + (b % 10) + (plus ? 1 : 0) < 10) {
				break;
			}
		}
		if (sum == 0) {
			printf("No carry operation.\n");
		}
		else if (sum == 1) {
			printf("%d carry operation.\n", sum);
		}
		else {
			printf("%d carry operations.\n", sum);
		}
	}
	system("pause");
	return 0;
}