#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int GCD(int S1,int S2) {
	if (S1 % S2 == 0) {
		return S2;
	}
	else
		return GCD(S2, S1 % S2);
}
int main() {
	int N = 0;
	scanf("%d", &N);
	for (int i = 0; i < N; i++) {
		char s1[30] = { 0 };
		char s2[30] = { 0 };
		scanf("%s %s", &s1, &s2);
		int count = 0;
		int S1 = 0, S2 = 0, S = 0;
		for (int j = strlen(s1) - 1; j >= 0 ; j--) {
			if (s1[j] == '0') {
				s1[j] = 0;
			}
			else if (s1[j] == '1') {
				s1[j] = 1;
			}
			S = s1[j] * pow(2, count);
			S1 = S + S1;
			count++;
		}
		count = 0;
		S = 0;
		for (int j = strlen(s2) - 1; j >= 0; j--) {
			if (s2[j] == '0') {
				s2[j] = 0;
			}
			else if (s2[j] == '1') {
				s2[j] = 1;
			}
			S = s2[j] * pow(2, count);
			S2 = S + S2;
			count++;
		}
		if (GCD(S1, S2) > 1) {
			printf("Pair #%d: All you need is love!\n", i + 1);
		}
		else {
			printf("Pair #%d: Love is not all you need!\n", i + 1);
		}
	}

	system("pause");
	return 0;
}