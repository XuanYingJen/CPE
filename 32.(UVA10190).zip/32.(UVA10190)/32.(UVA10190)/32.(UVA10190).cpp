/*
#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
#define lld long long int
lld func(lld a, lld b) {
	if (a == 1) {
		return 1;
	}
	else if (a % b == 0) {
		a = a / b;
		func(a, b);
	}
	else {
		printf("Boring!\n");
		return 0;
	}
}
void func1(lld temp_a, lld temp_b) {
	if (temp_a == 1) {
		printf("1\n");
		return;
	}
	else if (temp_a % temp_b == 0) {
		printf("%d ", temp_a);
		temp_a = temp_a / temp_b;
		func1(temp_a, temp_b);
	}
}
int main() {
	lld a = 0, b = 0;
	lld temp_a = 0, temp_b;
	while (scanf("%lld %lld", &a, &b) != EOF) {
		temp_a = a, temp_b = b;
		if (func(a, b) == 1) {
			func1(temp_a, temp_b);
		}
	}
	system("pause");
	return 0;
}
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#pragma warning(disable:4996)

int main() {
	int a = 0, b = 0;
	while (scanf("%d %d", &a, &b) != EOF) {
		int i = 1;
		int flag = 0;
		while (1) { 
			if (b == 0 || b == 1 || a < b) {
				flag = 1;
				break;
			}
			if ((int)pow(b, i) > a) {
				flag = 1;
				break;
			}
			else if ((int)pow(b, i) == a) {
				break;
			}
			i++;
		}
		if (flag == 1) {
			printf("Boring!\n");
		}
		else {
			for (int j = i; j > 0; j--) {
				printf("%d ", (int)pow(b, j));
			}
			printf("1\n");
		}
		
	}
	system("pause");
	return 0;
}
