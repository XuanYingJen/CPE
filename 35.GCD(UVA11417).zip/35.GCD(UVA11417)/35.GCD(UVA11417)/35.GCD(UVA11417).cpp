#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int GCD(int i,int j) {
	if (i % j == 0) {
		return j;
	}
	else {
		return GCD(j, i%j);
	}
}
int main() {
	int N = 0;
	while (1) {
		scanf("%d", &N);
		if (N == 0) break;
		int G = 0;
		for (int i = 1; i < N; i++) {
			for (int j = i + 1; j <= N; j++) {
				G += GCD(i, j);
			}
		}
		printf("%d\n", G);
	}
	system("pause");
	return 0;
}