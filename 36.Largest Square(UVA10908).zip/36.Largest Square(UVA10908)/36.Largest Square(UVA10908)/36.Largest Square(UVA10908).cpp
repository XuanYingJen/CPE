#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int T = 0, M = 0, N = 0, Q = 0;
	scanf("%d", &T);
	scanf("%d %d %d", &M, &N, &Q);

	system("pause");
	return 0;
}