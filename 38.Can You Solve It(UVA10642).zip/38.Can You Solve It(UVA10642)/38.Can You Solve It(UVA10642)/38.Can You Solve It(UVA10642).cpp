#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int test = 0;
	scanf("%d", &test);
	int Case = 0;
	for (int i = 0; i < test; i++) {
		Case++;
		int step = 0;
		int x = 0, y = 0;
		int xx = 0, yy = 0;
		scanf("%d %d %d %d", &x, &y, &xx, &yy);
		if (x + y == xx + yy) {
			step = xx - x;
		}
		else {
			step = (xx + yy) - (x + y) + (x + y) - x + (xx + yy) - yy;
			for (int j = x + y + 1; j < xx + yy; j++) {
				step = step + j;
			}
		}
		printf("Case %d: %d\n", Case, step);
	}
	system("pause");
	return 0;
}