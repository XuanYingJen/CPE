#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)

int main() {
	int a, b = 0;
	int n = 0;
	int sum = 0;
	while (scanf("%d %d", &a, &b) != EOF) {
		printf("%d %d ", a, b);
		if (a > b) {
			int temp = 0;
			temp = a;
			a = b;
			b = temp;
		}
		int max = 0;
		for (int i = a; i <= b; i++) {
			n = i;
			while (1) {
				if (n == 1) {
					sum++;
					break;
				}
				else if (n % 2 == 1) {
					n = n * 3 + 1;
					sum++;
				}
				else {
					n = n / 2;
					sum++;
				}
			}
			if (sum >= max) {
				max = sum;
			}
			sum = 0;
		}
		printf("%d\n", max);
	}
	system("pause");
	return 0;
}