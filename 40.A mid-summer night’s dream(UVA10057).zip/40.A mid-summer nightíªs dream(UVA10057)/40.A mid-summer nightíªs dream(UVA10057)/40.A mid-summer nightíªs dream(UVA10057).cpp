#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#pragma warning(disable:4996)
using namespace std;
int main() {
	int n = 0;
	while (scanf("%d", &n) != EOF) {
		int arr[1000] = { 0 };
		for (int i = 0; i < n; i++) {
			scanf("%d", &arr[i]);
		}
		sort(arr,arr+n);
		int mid = arr[(n - 1) / 2];
		int size_A = 0;
		int flag = 0;
		for (int j = 0; j < n; j++) {
			if (n % 2 == 1 && arr[j] == arr[(n - 1) / 2]) {
				size_A++;
			}
			else if(n % 2 == 0 && (arr[j] == arr[(n - 1) / 2] || arr[j] == arr[n / 2])){
				size_A++;
				flag = 1;
			}
		}
		if (flag == 0) {
			printf("%d %d %d\n", mid,size_A,1);
		}
		else printf("%d %d %d\n", mid, size_A, arr[n / 2] - arr[(n - 1) / 2]+1);
	}
	system("pause");
	return 0;
}