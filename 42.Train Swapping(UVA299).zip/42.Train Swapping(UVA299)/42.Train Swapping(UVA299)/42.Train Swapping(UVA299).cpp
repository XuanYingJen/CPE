#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int N = 0;
	scanf("%d", &N);
	for (int i = 0; i < N; i++) {
		int L = 0;
		scanf("%d", &L);
		int carriage[55] = { 0 };
		int count = 0;
		for (int i = 0; i < L; i++) {
			scanf("%d", &carriage[i]);
		}
		for (int i = 0; i < L; i++) {
			for (int j = 0; j < L - i - 1; j++) {
				if (carriage[j] > carriage[j + 1]) {
					int temp = carriage[j];
					carriage[j] = carriage[j + 1];
					carriage[j + 1] = temp;
					count++;
				}
			}
		}
		printf("Optimal train swapping takes %d swaps.\n", count);
	}
	system("pause");
	return 0;
}