#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int row = 0, column = 0;
	int Field = 0;
	scanf("%d %d", &row, &column);
	getchar();
	while (1) {
		if (row == 0 && column == 0) {
			break;
		}
		char arr[101][101] = { 0 };
		int count = 0;
		if (Field > 0) {
			printf("\n");
		}
		Field++;


		//enter��]��@�Ӧr��,�ҥH�n����
		/* getchar() -> �����r��*1(���Q%c���������̥���J��)*/
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				scanf("%c", &arr[i][j]);
			}
			getchar();
		}
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				count = 0;
				if (arr[i][j] == '.') {
					if (arr[i - 1][j - 1] == '*') {
						count++;
					}
					if (arr[i - 1][j] == '*') {
						count++;
					}
					if (arr[i - 1][j + 1] == '*') {
						count++;
					}
					if (arr[i][j - 1] == '*') {
						count++;
					}
					if (arr[i][j + 1] == '*') {
						count++;
					}
					if (arr[i + 1][j - 1] == '*') {
						count++;
					}
					if (arr[i + 1][j] == '*') {
						count++;
					}
					if (arr[i + 1][j + 1] == '*') {
						count++;
					}
					arr[i][j] = count + '0';
				}
			}
		}
		printf("Field #%d:\n", Field);
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				printf("%c", arr[i][j]);
			}
			printf("\n");
		}
		scanf("%d %d", &row, &column);
		getchar();
	}
	system("pause");
	return 0;
}