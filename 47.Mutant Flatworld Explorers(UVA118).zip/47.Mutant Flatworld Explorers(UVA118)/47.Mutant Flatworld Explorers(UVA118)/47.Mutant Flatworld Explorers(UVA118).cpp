#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int first() {

}
int main() {
	int X = 0, Y = 0;
	scanf("%d %d", &X, &Y);
	int mx = 0, my = 0;
	char direction = 0;
	while( scanf("%d %d %c", &mx, &my, &direction) != EOF){
	char move[100] = { 0 };
	scanf("%s", move);
	int flag = 0;
	int xrr[100] = { 0 }, yrr[100] = { 0 };
	char drr[100] = { 0 };
	for (int i = 0; move[i] != '\0'; i++) {
		if (direction == 'E') {
			if (move[i] == 'R') {
				direction = 'S';
			}
			else if (move[i] == 'L') {
				direction = 'N';
			}
			else if (move[i] == 'F') {
				mx++;
			}
		}
		else if (direction == 'W') {
			if (move[i] == 'R') {
				direction = 'N';
			}
			else if (move[i] == 'L') {
				direction = 'S';
			}
			else if (move[i] == 'F') {
				mx--;
			}
		}
		else if (direction == 'S') {
			if (move[i] == 'R') {
				direction = 'W';
			}
			else if (move[i] == 'L') {
				direction = 'E';
			}
			else if (move[i] == 'F') {
				my--;
			}
		}
		else if (direction == 'N') {
			if (move[i] == 'R') {
				direction = 'E';
			}
			else if (move[i] == 'L') {
				direction = 'W';
			}
			else if (move[i] == 'F') {
				my++;
			}
		}
		if (mx > X || my > Y) {
			flag++;
			int temp = i;
			i = flag;
			xrr[i] = mx;
			yrr[i] = my;
			drr[i] = direction;
			i = temp;
		}
	}
	}
	system("pause");
	return 0;
}