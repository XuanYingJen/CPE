#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
int main() {
	int n = 0;
	while (scanf("%d", &n) != EOF) {
		int answer1 = n, answer2 = n;
		int temp = n + 1;
		while (1) {
			answer1 = answer1 + n / 3;
			n = n / 3 + n % 3;
			if (n < 3) {
				break;
			}
		}
		while (1) {
			answer2 = answer2 + temp / 3;
			temp = temp / 3 + temp % 3;
			if (temp < 3) {
				break;
			}
		}
		if (answer1 > answer2) {
			printf("%d\n", answer1);
		}
		else {
			printf("%d\n", answer2);
		}
	}
	system("pause");
	return 0;
}