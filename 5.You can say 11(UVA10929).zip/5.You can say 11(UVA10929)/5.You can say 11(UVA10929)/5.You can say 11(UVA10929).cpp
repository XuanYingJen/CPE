#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#pragma warning(disable:4996)

int main() {
	char n[1005] = { 0 };
	int m[1005] = { 0 };
	while (1) {
		int sum1 = 0, sum2 = 0;
		scanf("%s", n);
		if (n[0] == '0' && strlen(n) == 1) {
			break;
		}
		for (int i = 0; n[i] != '\0'; i++) {
			if (n[i] == '0') {
				m[i] = 0;
			}
			else if (n[i] == '1') {
				m[i] = 1;
			}
			else if (n[i] == '2') {
				m[i] = 2;
			}
			else if (n[i] == '3') {
				m[i] = 3;
			}
			else if (n[i] == '4') {
				m[i] = 4;
			}
			else if (n[i] == '5') {
				m[i] = 5;
			}
			else if (n[i] == '6') {
				m[i] = 6;
			}
			else if (n[i] == '7') {
				m[i] = 7;
			}
			else if (n[i] == '8') {
				m[i] = 8;
			}
			else if (n[i] == '9') {
				m[i] = 9;
			}
			if (i % 2 == 0) {
				sum1 = sum1 + m[i];
			}
			else if (i % 2 == 1) {
				sum2 = sum2 + m[i];
			}
		}
		if (sum1 - sum2 == 0 || abs(sum1 - sum2) % 11 == 0) {
			for (int i = 0;n[i] != '\0'; i++) {
				printf("%c", n[i]);
			}
			printf(" is a multiple of 11.\n");
		}
		else {
			for (int i = 0;n[i] != '\0'; i++) {
				printf("%c", n[i]);
			}
			printf(" is not a multiple of 11.\n");
		}
	}
	system("pause");
	return 0;
}