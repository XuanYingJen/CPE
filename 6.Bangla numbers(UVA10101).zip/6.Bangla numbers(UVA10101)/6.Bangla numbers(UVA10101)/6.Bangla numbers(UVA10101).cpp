#include<stdio.h>
#include<stdlib.h>
#pragma warning(disable:4996)
#define lld long long int
lld judge(lld n) {
	if (n >= 10000000) {
		return 7;
	}
	else if (n >= 100000) {
		return 5;
	}
	else if (n >= 1000) {
		return 3;
	}
	else if (n >= 100) {
		return 2;
	}
	else
		return 0;
}
lld function(lld n) {
	if (n >= 10000000) {
		printf(" %lld kuti", n / 10000000);
		return function(n % 10000000);
	}
	else if (n >= 100000) {
		printf(" %lld lakh", n / 100000);
		return function(n % 100000);
	}
	else if (n >= 1000) {
		printf(" %lld hajar", n / 1000);
		return function(n % 1000);
	}
	else if (n >= 100) {
		printf(" %lld shata", n / 100);
		return function(n % 100);
	}
	else
		if (n != 0) {
			printf(" %lld", n);
		}
		return n;
}
int main() {
	lld n = 0;
	lld surplus = 0;
	int test = 0;
	lld kuti = 10000000, lakh = 100000, hajar = 1000, shata = 100, last = 0;
	while (scanf("%lld", &n) != EOF) {
		test++;
		printf("%4d.", test);
		if (judge(n) == 7) {
			surplus = n % 10000000;
			n = n / 10000000;
			function(n);
			printf(" kuti");
			function(surplus);
		}
		else if (judge(n) == 5) {
			surplus = n % 100000;
			n = n / 100000;
			function(n);
			printf(" lakh");
			function(surplus);
		}
		else if (judge(n) == 3) {
			surplus = n % 1000;
			n = n / 1000;
			function(n);
			printf(" hajar");
			function(surplus);
		}
		else if (judge(n) == 2) {
			surplus = n % 100;
			n = n / 100;
			function(n);
			printf(" shata");
			function(surplus);
		}
		else {
			function(n);
			if (n == 0) {
				printf(" 0");
			}
		}
		printf("\n");
	}

	system("pause");
	return 0;
}
/*
#include<stdio.h>
#include<stdlib.h>
#pragma warning (disable:4996)
#define lld long long int

lld func(lld a)
{
	while (a > 0)
	{
		lld b = 0;
		if (a >= 10000000)
		{
			lld  kuti = a / 10000000;
			a = a - (kuti * 10000000);
			if (kuti >= 0)
			{
				b = func(kuti);
			}
			if (b == 0)
			{
				if (a == 0)
					printf("kuti");
				else
					printf("kuti ");
			}
			else
			{
				if (a == 0)
					printf(" kuti");
				else
					printf(" kuti ");
			}



		}
		else if (a >= 100000)
		{
			lld lakh = a / 100000;
			a = a - (lakh * 100000);
			if (a == 0)
				printf("%lld lakh", lakh);
			else
				printf("%lld lakh ", lakh);

		}
		else if (a >= 1000)
		{
			lld hajar = a / 1000;
			a = a - (hajar * 1000);
			if (a == 0)
				printf("%lld hajar", hajar);
			else
				printf("%lld hajar ", hajar);

		}
		else if (a >= 100)
		{
			lld shata = a / 100;
			a = a - (shata * 100);
			if (a == 0)
				printf("%lld shata", shata);
			else
				printf("%lld shata ", shata);

		}
		else if (a>0)
		{
			printf("%lld", a);
			return a;
			a = 0;
		}

	}
}
int main()
{
	lld a = 0;
	int i = 1;
	while (scanf("%lld", &a) != EOF)
	{
		if (a == 0)
		{
			printf("%4d. ", i);
			printf("%lld", 0);
			i++;
			printf("\n");
		}
		else
		{
			printf("%4d. ", i);
			func(a);
			i++;
			printf("\n");
		}
	}
	system("pause");
	return 0;
}
//e ��kuti��(10000000), ��lakh��(100000), ��hajar��(1000), ��shata��(100)
*/