#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#pragma warning(disable:4996)

int main() {
	int n = 0;
	char str[1000][1000];
	int upper[27] = { 0 };
	int count[27] = { 0 };
	scanf("%d", &n);
	getchar();
	for(int i = 0;i < n;i++){
		gets_s(str[i]);
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; str[i][j] != '\0'; j++) {
			if (isupper(str[i][j]) != 0 || islower(str[i][j]) != 0) {
				count[toupper(str[i][j]) - 'A' + 1]++;//�r������
			}
		}
	}
	for (int i = 1; i < 27; i++) {
		upper[i] = i;//�r������
	}
	for (int i = 1; i < 27; i++) {
		for (int j = 1; j < 27 - i - 1; j++) {
			if (count[j] < count[j + 1]) {
				int temp = count[j];
				count[j] = count[j + 1];
				count[j + 1] = temp;
				temp = upper[j];
				upper[j] = upper[j + 1];
				upper[j + 1] = temp;
			}
		}
	}
	for (int i = 1; i < 27; i++) {
		if (count[i] != 0) {
			printf("%c %d\n", upper[i] + 'A'- 1 , count[i]);
		}
	}
	system("pause");
	return 0;
}