#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#pragma warning(disable:4996)

int main() {
	int n = 0;
	char country[2000][75] = {0};
	scanf("%d", &n);
	getchar();
	for (int i = 0; i < n; i++) {
		gets_s(country[i]);
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < 5; j++) {
			) {
			}
		}
	}
		
	for (int i = 0; i < n; i++) {
		for (int j = 0; country[i][j] != ' '; j++) {
			printf("%c", country[i][j]);
		}
		printf("\n");
	}
	system("pause");
	return 0;
}