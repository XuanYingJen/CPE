#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#pragma warning(disable:4996)
int degree(int sum,int count,int num) {
	num = num + sum - (sum / 10) * 10;
	if (num < 10 && sum < 10) {
		return count + 1;
	}
	else if (sum < 10) {
		count++;
		return degree(num, count, 0);
	}
	else
		return degree(sum / 10, count, num);

}
int main() {
	while (1) {
		char str[1000] = { 0 };
		gets_s(str);
		if (strlen(str) == 1 && str[0] =='0') {
			break;
		}
		int sum = 0;
		int num = 0;
		int count = 0;
		for (int i = 0; i < strlen(str); i++) {
			sum = sum + str[i] - '0';
			printf("%c", str[i]);
		}
		if (sum > 10) {
			count++;
		}
		if (sum % 9 != 0) {
			printf(" is not a multiple of 9.\n");
		}
		else {
			degree(sum, count, num);
			printf(" is a multiple of 9 and has 9-degree %d.\n",degree(sum,count,num));
		}
	}
	system("pause");
	return 0;
}